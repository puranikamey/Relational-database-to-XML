package xmlformation;

import java.util.*;
import java.io.*;

//global class
public class xmldept {
	//initializing an array
	public static String data[] = new String[50];
	public String d[];
	//declaring arraylist.
	ArrayList<String> pno = new ArrayList<String>();

	public static void main(String[] args) {
		System.out.println("<?xml version=1.0 encoding= UTF-8?>\n"+"<DepartmentInformation>");
		xmldept obj = new xmldept();
		data = obj.reading();

	}
	///method returning string array.
	public String[] reading(){
		FileInputStream fis = null;
		BufferedReader reader = null;
		String[] myarray;
		
		myarray = new String[50];
		try{
			//declaring file location.
			fis = new FileInputStream("E:/root/dept.txt");
			reader = new BufferedReader(new InputStreamReader(fis));
			int i = 0;
			String line = reader.readLine();
			
			while (line != null) {
				myarray[i] = line;
				line = reader.readLine();
				
				d=myarray[i].split(",");
				//if loop
				if (pno.isEmpty()){
					
					pno.add(d[0]);
					System.out.println("<Department>");
					System.out.println("    <Department_Name>" + d[0]+"</Department_Name>");
					System.out.println("    <Manager>" + d[1]+"</Manager>");
					System.out.println("<Dept_locations>");
					System.out.println("    <Dlocation>" + d[2]+"</Dlocation>");
					
					
					
				}
				//if loop to check if element exists in the arraylist
				
				else if (pno.contains(d[0])){
					
					pno.add(d[0]);
				
				
					System.out.println("    <Dlocation>" + d[2]+"</Dlocation>");
					

		
				}
				
				//if loop to check if element exists in the arraylist
				else	if (pno.contains(d[0])==false){
					
					pno.add(d[0]); //adding department name inthe array
					
					System.out.println("</Dept_locations");
					    System.out.println("</Department>");
						System.out.println("<Department>");
						System.out.println("    <Department_Name>" + d[0]+"</Department_Name>");
						System.out.println("    <Manager>" + d[1]+"</Manager>");
						System.out.println("<Dept_locations>");
						System.out.println("    <Dlocation>" + d[2]+"</Dlocation>");
						
					
			}
				
				i++;  ///incrementing i;
				
			}
			
		
			
			reader.close();
			//closing buffereader.
			
			
		}catch(Exception e){}
		
		
		
		System.out.println("</Dept_locations");
		System.out.println("</Department>");
		System.out.println("</DepartmentInforamtion>");
		return myarray; ///returning string array
		
		
		
	}
}
