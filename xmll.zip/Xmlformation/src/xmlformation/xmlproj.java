package xmlformation;
//importing util and input/output packages 
import java.util.*;
import java.io.*;


//global class
public class xmlproj {
  //initializing an array;
	public static String data[] = new String[50];
	public String d[];
	//declaring arraylist.
	ArrayList<String> pno = new ArrayList<String>();

	public static void main(String[] args) {
		System.out.println("<?xml version=1.0 encoding= UTF-8?>\n "+"<ProjectInformation>");
		xmlproj obj = new xmlproj();
		data = obj.reading();

	}
///method returning string array.
	public String[] reading(){
		FileInputStream fis = null; ///initializing file input stream reader.
		BufferedReader reader = null;
		String[] myarray;
		myarray = new String[50];
		try{
			//declaring file location.
			fis = new FileInputStream("E:/root/project.txt");
			reader = new BufferedReader(new InputStreamReader(fis));
			int i = 0;
			String line = reader.readLine();
			
			while (line != null) {
				myarray[i] = line;
				line = reader.readLine();
				
				d=myarray[i].split(",");
				//if loop
				if (pno.isEmpty()){
					
					pno.add(d[0]);
					System.out.println("<Project>");
					System.out.println("    <Projectnumber>" + d[0]+"</projectnumber>");
					System.out.println("    <ProjectName>" + d[1]+"</ProjectName>");
					System.out.println("    <Department >" + d[2]+"</Department>");
					System.out.println("<EmpDetails>");
					System.out.println("    <lastname>" + d[3]+"</lastname>");
					System.out.println("    <Firstname>" + d[4]+"</Firstname>");
					System.out.println("    <Hours >" + d[5]+"</Hours>");
					
					
				}
				//if loop to check if element exists in the arraylist
				else if (pno.contains(d[0])){
					
					pno.add(d[0]); //adding department name inthe array
				
					System.out.println("</EmpDetails>");
					System.out.println("<EmpDetails>");
					System.out.println("    <lastname>" + d[3]+"</lastname>");
					System.out.println("    <Firstname>" + d[4]+"<Firstname>");
					System.out.println("    <Hours >" + d[5]+"</Hours>");
					

				}
				
				//if loop to check if element exists in the arraylist
				else	if (pno.contains(d[0])==false){
					
					pno.add(d[0]); //adding department name inthe array
					
					System.out.println("</EmpDetails");
					    System.out.println("</Project>");
						System.out.println("<Project>");
						System.out.println("    <Projectnumber>" + d[0]+"</projectnumber>");
						System.out.println("    <ProjectName>" + d[1]+"</ProjectName>");
						System.out.println("    <Department >" + d[2]+"</Department>");
						System.out.println("<EmpDetails>");
						System.out.println("    <lastname>" + d[3]+"</lastname>");
						System.out.println("    <Firstname>" + d[4]+"</Firstname>");
						System.out.println("    <Hours >" + d[5]+"</Hours>");
						
						
					
			}
				///incrementing i;
				i++;
				
			}
			
	
			reader.close();
			//closing buffereader.
			
			
		}catch(Exception e){}
		
		
		System.out.println("</EmpDetails");
		System.out.println("</Project>");
		System.out.println("</ProjectInformation>");
		return myarray;///returning string array
		
		
		
	}

}
